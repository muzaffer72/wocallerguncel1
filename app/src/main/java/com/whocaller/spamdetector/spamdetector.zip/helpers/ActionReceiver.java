package com.whocaller.spamdetector.helpers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telecom.Call;
import android.util.Log;
import com.whocaller.spamdetector.activities.CallActivity;

public class ActionReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.hasExtra("endCall")) {
            // Çağrı bitir
            CallManager cm = new CallManager(context);
            Call call = cm.getCall();
            if (call != null) {
                CallManager.hangUpCall(call);
            }
        } else if (intent.hasExtra("speakerCall")) {
            // Hoparlör durumunu değiştir
            CallActivity.isSpeakerOn = !CallActivity.isSpeakerOn;
            CallManager.speakerCall(CallActivity.isSpeakerOn);
        } else if (intent.hasExtra("muteCall")) {
            // Çağrıyı sessize al/çıkar
            CallActivity.isMuted = !CallActivity.isMuted;
            CallManager.muteCall(CallActivity.isMuted);
        }
    }
}
