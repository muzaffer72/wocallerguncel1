/*
 * Company : AndroPlaza
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Buddhika
 * Contact : support@androplaza.shop
 * Whatsapp : +94711920144
 */

package com.whocaller.spamdetector.modal;

public class ErrorResponse {
    private String message;
    private String error;

    public String getMessage() {
        return message;
    }

    public String getError() {
        return error;
    }
}
