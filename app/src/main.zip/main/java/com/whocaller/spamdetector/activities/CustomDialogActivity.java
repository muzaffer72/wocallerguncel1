package com.whocaller.spamdetector.activities;

import static com.whocaller.spamdetector.utils.Utils.generateAvatar;
import static com.whocaller.spamdetector.utils.Utils.getLookupKeyFromPhoneNumber;
import static com.whocaller.spamdetector.utils.Utils.isPhoneNumberSaved;
import static com.whocaller.spamdetector.utils.Utils.isValidName;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;

import com.bumptech.glide.Glide; // Profil resmini internetten çekmek için
import com.whocaller.spamdetector.R;
import com.whocaller.spamdetector.ads.Ads;
import com.whocaller.spamdetector.database.sqlite.BlockCallerDbHelper;
import com.whocaller.spamdetector.databinding.ActivityCustomDialogBinding;
import com.whocaller.spamdetector.modal.Contact;
import com.whocaller.spamdetector.utils.Utils;
import com.naliya.callerid.database.prefs.SettingsPrefHelper;

import java.util.List;

public class CustomDialogActivity extends AppCompatActivity {

    // ---------------------------------------------------------
    // Orijinal değişkenler (kod yapısını bozmuyoruz)
    Contact contactModal;
    Intent intent;
    boolean isBlock = false;
    BlockCallerDbHelper blockCallerDbHelper;

    // ViewBinding
    ActivityCustomDialogBinding binding;

    // ---------------------------------------------------------
    // LIVEDATA DEĞİŞKENLERİ
    // 1) Contact için (isim, numara, spam vb.)
    private MutableLiveData<Contact> contactLiveData = new MutableLiveData<>();
    // 2) Bloklanma durumu
    private MutableLiveData<Boolean> blockStatusLiveData = new MutableLiveData<>();
    // 3) (Opsiyonel) “n” alanı gibi dinamik bir mesajı yönetmek isterseniz
    private MutableLiveData<String> callStatusLiveData = new MutableLiveData<>();
    // 4) Profil resmi için LiveData (URL veya Drawable ya da Bitmap olabilir)
    private MutableLiveData<String> profileImageUrlLiveData = new MutableLiveData<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1) Pencere ayarları
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        binding = ActivityCustomDialogBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // 2) Reklam gösterimi vb.
        SettingsPrefHelper settingsPrefHelper = new SettingsPrefHelper(this);
        if (Utils.isNetworkAvailable(this)) {
            Ads ads = new Ads(this);
            ads.loadingNativeAd(this);
        }
        setFinishOnTouchOutside(false);

        // 3) Gravity ayarları
        Window window = getWindow();
        if (window != null) {
            WindowManager.LayoutParams params = window.getAttributes();
            switch (settingsPrefHelper.getCallerIdPosition()) {
                case "Top":
                    params.gravity = Gravity.TOP;
                    break;
                case "Center":
                    params.gravity = Gravity.CENTER;
                    break;
                case "Bottom":
                    params.gravity = Gravity.BOTTOM;
                    break;
                default:
                    params.gravity = Gravity.CENTER;
                    break;
            }
            params.width = WindowManager.LayoutParams.MATCH_PARENT;
            params.y = 0;
            window.setAttributes(params);
        }

        // 4) DB helper init
        blockCallerDbHelper = new BlockCallerDbHelper(this);

        // 5) Kapanış butonu
        binding.closeIcon.setOnClickListener(v -> finish());

        // ---------------------------------------------------------
        // LIVEDATA OBSERVERS

        // A) contactLiveData -> Gelen Contact nesnesiyle UI'ı doldur
        contactLiveData.observe(this, new Observer<Contact>() {
            @Override
            public void onChanged(Contact contact) {
                if (contact == null) return;

                // 1) Ad, numara
                binding.callerName.setText(Utils.toTextCase(contact.getName()));
                binding.callerNumber.setText(contact.getPhoneNumber());

                // 2) Şebeke / Ülke
                String carrier = contact.getCarrierName();
                String country = contact.getCountryName();
                if (carrier != null && !carrier.equals("null")) {
                    binding.network.setVisibility(View.VISIBLE);
                    binding.network.setText(carrier);
                } else {
                    binding.network.setVisibility(View.GONE);
                }
                if (country != null && !country.equals("null")) {
                    binding.country.setVisibility(View.VISIBLE);
                    binding.country.setText(country);
                } else {
                    binding.country.setVisibility(View.GONE);
                }

                // 3) Profil resmi mantığı (spam / block / normal)
                //    spam veya block ise direk Drawable; aksi halde contact içinden URL veya generateAvatar
                if (contact.isSpam()) {
                    // Spam durumunda direk spam_circle göstermek isteyebiliriz
                    binding.profilePic.setImageDrawable(ContextCompat.getDrawable(CustomDialogActivity.this, R.drawable.spam_circle));
                    // LiveData'ya da null verebilirsiniz ki Observer'da Glide çalışmasın
                    profileImageUrlLiveData.setValue(null);
                } else {
                    // Spam değilse normal resim
                    // Örneğin contact modal'da "imageUrl" varsa:
                    // if (contact.getImageUrl() != null) { ... } else { generateAvatar }

                    // Avatar veya bir URL
                    if (contact.getImageUrl() != null && !contact.getImageUrl().isEmpty()) {
                        // URL'yi LiveData'ya atıyoruz. Observer'da Glide ile yüklenecek
                        profileImageUrlLiveData.setValue(contact.getImageUrl());
                    } else {
                        // Eğer contact image URL yoksa avatar:
                        // setValue("") => Observer'da yakalayıp avatar çizeceğiz
                        profileImageUrlLiveData.setValue("");
                    }
                }

                // whoProfile
                if (contact.isWho()) {
                    binding.whoProfile.setVisibility(View.VISIBLE);
                } else {
                    binding.whoProfile.setVisibility(View.GONE);
                }
            }
        });

        // B) blockStatusLiveData -> Engelleme durumu
        blockStatusLiveData.observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean blocked) {
                // Orijinal isBlock değişkeni de güncellensin
                isBlock = (blocked != null && blocked);
                if (isBlock) {
                    binding.blockTxt.setText(getString(R.string.unblock));
                    // Bloklanınca profil resmi block_circle olarak değişiyor
                    binding.profilePic.setImageDrawable(ContextCompat.getDrawable(CustomDialogActivity.this, R.drawable.block_circle));
                    // URL livedata'yı sıfırlayabiliriz (opsiyonel)
                    profileImageUrlLiveData.setValue(null);
                } else {
                    binding.blockTxt.setText(getString(R.string.block));
                }
            }
        });

        // C) callStatusLiveData -> “n” alanı gibi özel bir metin göstermek isterseniz
        callStatusLiveData.observe(this, new Observer<String>() {
            @Override
            public void onChanged(String msg) {
                binding.n.setText(msg);
            }
        });
        // callStatusLiveData.setValue(getString(R.string.call_ended_less_than_1m_ago));

        // D) profileImageUrlLiveData -> Asıl profil resmi yükleme
        profileImageUrlLiveData.observe(this, new Observer<String>() {
            @Override
            public void onChanged(String urlOrEmpty) {
                // Eğer null veya boşsa "generateAvatar" gösterelim
                if (urlOrEmpty == null) {
                    // Bir önceki spam/block durumu (Drawable) kalsın diye isterseniz burada hiçbir şey yapmayabilirsiniz
                    return;
                }
                if (urlOrEmpty.isEmpty()) {
                    // Boş string => Avatar
                    // contactLiveData'dan isme ulaşabiliriz:
                    Contact currentContact = contactLiveData.getValue();
                    if (currentContact != null) {
                        if (isValidName(currentContact.getName())) {
                            binding.profilePic.setImageBitmap(generateAvatar(currentContact.getName()));
                        } else {
                            binding.profilePic.setImageBitmap(generateAvatar("U"));
                        }
                    }
                } else {
                    // Gerçek URL => Glide ile yükleyelim
                    Glide.with(CustomDialogActivity.this)
                            .load(urlOrEmpty)
                            .placeholder(R.drawable.ic_avatar)
                            .error(R.drawable.ic_avatar)
                            .into(binding.profilePic);
                }
            }
        });

        // ---------------------------------------------------------
        // INTENT KONTROLLERİ
        intent = getIntent();
        if (intent != null) {
            // 1) “modal” Parceled Contact geldiyse
            if (intent.getParcelableExtra("modal") != null) {
                contactModal = intent.getParcelableExtra("modal");
                contactLiveData.setValue(contactModal);

                // Blok durumu
                isBlock = blockCallerDbHelper.isPhoneNumberBlocked(contactModal.getPhoneNumber());
                blockStatusLiveData.setValue(isBlock);

                // Dialog actionlar
                dialogAction(contactModal.getPhoneNumber(), contactModal.getName());

                // Butonlar
                binding.btnBlock.setOnClickListener(v ->
                        showConfirmBlockDialog(contactModal.getPhoneNumber(), contactModal.getName()));
                binding.viewProfile.setOnClickListener(v -> {
                    Intent contactDetailIntent = new Intent(CustomDialogActivity.this, ContactDetailsActivity.class);
                    contactDetailIntent.putExtra("modal", contactModal);
                    contactDetailIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(contactDetailIntent);
                    finish();
                });

                // WhatsApp & SMS
                setupWhatsAppAndSmsButtons(contactModal.getPhoneNumber());
            }
            // 2) Sadece String name/number geldiyse
            else if (intent.getStringExtra("callerName") != null && intent.getStringExtra("callerNumber") != null) {
                String callerName = intent.getStringExtra("callerName");
                String callerNumber = intent.getStringExtra("callerNumber");

                // Geçici Contact oluştur
                Contact tempContact = new Contact();
                tempContact.setName(callerName);
                tempContact.setPhoneNumber(callerNumber);

                // İsterseniz bir "setImageUrl(...)" ekleyerek doldurabilirsiniz
                // tempContact.setImageUrl("http://example.com/path/to/profile.jpg");

                contactModal = tempContact;

                // LiveData üzerinden UI güncelle
                contactLiveData.setValue(tempContact);

                // Blok durumu
                isBlock = blockCallerDbHelper.isPhoneNumberBlocked(callerNumber);
                blockStatusLiveData.setValue(isBlock);

                // Dialog action
                dialogAction(callerNumber, callerName);

                // Butonlar
                binding.btnBlock.setOnClickListener(v ->
                        showConfirmBlockDialog(callerNumber, callerName));
                binding.viewProfile.setOnClickListener(v -> {
                    Intent contactDetailIntent = new Intent(CustomDialogActivity.this, ContactDetailsActivity.class);
                    contactDetailIntent.putExtra("name", callerName);
                    contactDetailIntent.putExtra("phoneNumber", callerNumber);
                    contactDetailIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(contactDetailIntent);
                    finish();
                });

                // WhatsApp & SMS
                setupWhatsAppAndSmsButtons(callerNumber);
            }
        }
    }

    // ---------------------------------------------------------
    // WhatsApp ve SMS butonları
    private void setupWhatsAppAndSmsButtons(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            Toast.makeText(this, "Geçerli bir telefon numarası yok.", Toast.LENGTH_SHORT).show();
            return;
        }
        // WhatsApp
        binding.btnWhatsapp.setOnClickListener(v -> {
            String message = " ";
            String formattedPhoneNumber = "+" + phoneNumber;
            String url = "https://wa.me/" + formattedPhoneNumber + "?text=" + Uri.encode(message);
            Intent sendIntent = new Intent(Intent.ACTION_VIEW);
            sendIntent.setData(Uri.parse(url));

            // Samsung cihazları
            if (isSamsungDevice()) {
                try {
                    Intent samsungIntent = new Intent(sendIntent);
                    samsungIntent.setPackage("com.whatsapp");
                    startActivity(samsungIntent);
                    return;
                } catch (ActivityNotFoundException e) {
                    Log.e("WhatsApp", "Samsung cihazında WhatsApp bulunamadı.");
                }
            }
            // WhatsApp yüklü mü?
            PackageManager packageManager = getPackageManager();
            List<ResolveInfo> activities = packageManager.queryIntentActivities(sendIntent, PackageManager.MATCH_DEFAULT_ONLY);
            if (activities.size() > 0) {
                startActivity(sendIntent);
            } else {
                Toast.makeText(this, "WhatsApp yüklü değil!", Toast.LENGTH_SHORT).show();
            }
        });

        // SMS
        binding.btnSms.setOnClickListener(v -> {
            String message = " ";
            String formattedPhoneNumber = "+" + phoneNumber;
            Intent sendIntent = new Intent(Intent.ACTION_VIEW);
            sendIntent.setData(Uri.parse("sms:" + formattedPhoneNumber));
            sendIntent.putExtra("sms_body", message);

            if (sendIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(sendIntent);
            } else {
                Toast.makeText(this, "SMS uygulaması bulunamadı!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean isSamsungDevice() {
        return android.os.Build.MANUFACTURER.equalsIgnoreCase("samsung");
    }

    // ---------------------------------------------------------
    // dialogAction: orijinal kod
    public void dialogAction(String number, String name) {
        if (isPhoneNumberSaved(number, this)) {
            binding.btnSave.setVisibility(View.GONE);
            binding.btnEdit.setVisibility(View.VISIBLE);
            binding.btnEdit.setOnClickListener(v -> {
                String lKey = getLookupKeyFromPhoneNumber(number, CustomDialogActivity.this);
                if (lKey != null) {
                    Utils.openContactEditPage(CustomDialogActivity.this, lKey);
                }
            });
        } else {
            binding.btnEdit.setVisibility(View.GONE);
            binding.btnSave.setVisibility(View.VISIBLE);
            binding.btnSave.setOnClickListener(v -> Utils.openContactCreatePage(CustomDialogActivity.this, number, name));
        }
        binding.btnCall.setOnClickListener(v -> Utils.makeCall(number, CustomDialogActivity.this));
    }

    // ---------------------------------------------------------
    // Engelleme Onay Dialog
    private void showConfirmBlockDialog(String number, String name) {
        String message;
        String title;
        if (isBlock) {
            message = getString(R.string.do_you_want_to_unblock_this_contact);
            title = getString(R.string.confirm_unblock);
        } else {
            message = getString(R.string.do_you_want_to_block_this_contact);
            title = getString(R.string.confirm_block);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setTitle(title)
                .setPositiveButton("Yes", (dialog, id) -> {
                    if (isBlock) {
                        if (blockCallerDbHelper.deleteBlockCallerByPhoneNumber(number)) {
                            // LiveData ile güncelle
                            blockStatusLiveData.setValue(false);
                        }
                    } else {
                        if (blockCallerDbHelper.addBlockCaller(name, number)) {
                            blockStatusLiveData.setValue(true);
                        }
                    }
                })
                .setNegativeButton("No", (dialog, id) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
