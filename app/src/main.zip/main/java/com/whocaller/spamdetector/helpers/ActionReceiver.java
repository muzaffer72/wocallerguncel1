package com.whocaller.spamdetector.helpers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;

import com.whocaller.spamdetector.services.TelecomAdapter;

public class ActionReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // İşlem yapılacak aksiyonlar
        String action = intent.getStringExtra("endCall");

        if (action != null && action.equals("YES")) {
            endCall(context);  // Çağrıyı sonlandır
        }

        action = intent.getStringExtra("speakerCall");
        if (action != null && action.equals("YES")) {
            toggleSpeaker(context);  // Hoparlörü aç/kapa
        }

        action = intent.getStringExtra("muteCall");
        if (action != null && action.equals("YES")) {
            toggleMute(context);  // Mikrofonu mute et/kaldır
        }
    }

    // Çağrıyı sonlandırma işlemi
    private void endCall(Context context) {
        TelecomAdapter telecomAdapter = TelecomAdapter.getInstance();
        telecomAdapter.endCall(context);  // TelecomManager ile çağrıyı sonlandır
    }

    // Hoparlör açma/kapama işlemi
    private void toggleSpeaker(Context context) {
        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (audioManager != null) {
            TelecomAdapter telecomAdapter = TelecomAdapter.getInstance();
            telecomAdapter.switchSpeaker(audioManager);  // Hoparlörü aç/kapa
        }
    }

    // Sesi açma/kapama işlemi (Mute)
    private void toggleMute(Context context) {
        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (audioManager != null) {
            TelecomAdapter telecomAdapter = TelecomAdapter.getInstance();
            telecomAdapter.muteSpeaker(audioManager);  // Mikrofonu mute et/kaldır
        }
    }
}
