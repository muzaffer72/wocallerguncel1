package com.whocaller.spamdetector.helpers;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.telecom.Call;
import android.util.Log;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.whocaller.spamdetector.R;
import com.whocaller.spamdetector.activities.CallActivity;

/**
 * NotificationHelper:
 *  - Gelen/Giden çağrı bildirimi oluşturma
 *  - Zil sesini çalma/durdurma
 *  - Çağrı durum değişikliğinde bildirim yönetimi
 */
public class NotificationHelper {

    private static final String TAG = "NotificationHelper";
    public static final int NOTIFICATION_ID = 834831;

    // Bildirim kanal bilgileri
    private static final String CHANNEL_ID = "Hidden_Pirates_Phone_App";
    private static final String CHANNEL_NAME = "Incoming Call Notification";

    // Zil sesi yönetimi
    private static Ringtone ringtone;
    private static boolean isRingtonePlaying = false;

    // Çağrı durumu izleme
    private static boolean isInCall = false;
    private static int lastCallState = -1;

    // Zil sesinin kim tarafından (Activity mi, NotificationHelper mı) yönetildiğini gösterir
    // Eğer TRUE ise Activity kendi zil sesini çalar/durdurur, NotificationHelper müdahale etmez.
    private static boolean isRingtoneHandledByActivity = false;

    /**
     * Aktivite, zil sesini kendisi yönetmeye başladığında bu metot çağrılarak
     * NotificationHelper’ın zil sesi çalmaması/durdurmaması sağlanır.
     */
    public static void setRingtoneHandledByActivity(boolean isHandled) {
        isRingtoneHandledByActivity = isHandled;
        Log.d(TAG, "Ringtone is now handled by activity: " + isHandled);
    }

    /**
     * Gelen çağrı bildirimi oluşturup (Activity yönetmiyorsa) zil sesini başlatır.
     */
    public static void createIngoingCallNotification(Context context, Call call, String callDuration,
                                                     String speakerBtnTxt, String muteBtnTxt) {
        if (call == null) {
            Log.e(TAG, "createIngoingCallNotification: Call is null");
            return;
        }

        int currentCallState = call.getState();
        Log.d(TAG, "Incoming call state: " + getCallStateString(currentCallState));

        // Aynı durumu tekrar işleme
        if (currentCallState == lastCallState) {
            return;
        }
        lastCallState = currentCallState;

        // Çağrı RINGING haricinde ise (aktif, bağlantı kuruluyor vs.), zil sesini durdurup
        // basit bir çağrı bildirimi gösterilebilir.
        if (currentCallState != Call.STATE_RINGING) {
            if (!isRingtoneHandledByActivity) {
                stopRingtone();
            }
            isInCall = (currentCallState == Call.STATE_ACTIVE);

            if (currentCallState == Call.STATE_ACTIVE ||
                    currentCallState == Call.STATE_DIALING ||
                    currentCallState == Call.STATE_CONNECTING) {
                // Giden/aktif çağrı bildirimi
                showCallNotification(context, call, callDuration, speakerBtnTxt, muteBtnTxt, false);
            }
            return;
        }

        // Bildirimi göster (gelen arama durumu)
        showCallNotification(context, call, callDuration, speakerBtnTxt, muteBtnTxt, true);

        // Zil sesi Activity tarafından yönetiliyorsa burada çalma
        if (isRingtoneHandledByActivity) {
            Log.d(TAG, "Ringtone is handled by activity, skipping NotificationHelper playback");
            return;
        }

        // Zil sesi zaten çalıyorsa tekrar başlatma
        if (isRingtonePlaying) {
            return;
        }

        // Zil sesini başlat
        playRingtone(context);
    }

    /**
     * Giden çağrı bildirimi (zilsiz) oluşturur.
     */
    public static void createOutgoingNotification(Context context, Call call) {
        if (call == null) {
            Log.e(TAG, "createOutgoingNotification: Call is null");
            return;
        }
        // Eğer NotificationHelper zil sesini çalıyorsa, durdur
        if (!isRingtoneHandledByActivity) {
            stopRingtone();
        }

        showCallNotification(context, call, "Aranıyor...", "Hoparlör", "Sessiz", false);
    }

    /**
     * Çağrı bildirimi oluşturma/güncelleme
     *
     * @param isIncoming Gelen çağrı mı? (true ise butonlar eklenir)
     */
    private static void showCallNotification(Context context, Call call, String callDuration,
                                             String speakerBtnTxt, String muteBtnTxt, boolean isIncoming) {
        if (call == null) return;

        // Kişi adı veya numarasını al
        String callerPhoneNumber = call.getDetails().getHandle().getSchemeSpecificPart();
        String callerName = ContactsHelper.getContactNameFromLocal(callerPhoneNumber, context);

        createNotificationChannelIfNeeded(context);

        // Bildirimi açtığımızda CallActivity'ye gidecek Intent
        Intent callIntent = new Intent(context, CallActivity.class);
        callIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);

        PendingIntent callPendingIntent = PendingIntent.getActivity(
                context,
                0,
                callIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Bildirim
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(callPendingIntent)
                .setFullScreenIntent(callPendingIntent, true)
                .setSmallIcon(R.drawable.ic_call_green)
                .setContentInfo(callDuration)
                .setContentTitle(callerName)
                .setContentText(callerPhoneNumber)
                .setCategory(Notification.CATEGORY_CALL)
                .setChannelId(CHANNEL_ID)
                .setOnlyAlertOnce(true)
                .setSilent(true); // Bildirim sesini kapat (Zil sesini manuel yönetiyoruz)

        // Gelen veya aktif çağrı ise butonları ekleyelim
        if (isIncoming || call.getState() == Call.STATE_ACTIVE) {
            // Çağrı bitir
            Intent endCallIntent = new Intent(context, ActionReceiver.class);
            endCallIntent.putExtra("endCall", "YES");
            PendingIntent endCallPendingIntent = PendingIntent.getBroadcast(
                    context,
                    1,
                    endCallIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            builder.addAction(R.drawable.ic_call_end_red, context.getString(R.string.end_call), endCallPendingIntent);

            // Hoparlör butonu
            Intent speakerCallIntent = new Intent(context, ActionReceiver.class);
            speakerCallIntent.putExtra("speakerCall", "YES");
            PendingIntent speakerCallPendingIntent = PendingIntent.getBroadcast(
                    context,
                    2,
                    speakerCallIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            builder.addAction(R.drawable.ic_volume_up, speakerBtnTxt, speakerCallPendingIntent);

            // Sessiz butonu
            Intent muteCallIntent = new Intent(context, ActionReceiver.class);
            muteCallIntent.putExtra("muteCall", "YES");
            PendingIntent muteCallPendingIntent = PendingIntent.getBroadcast(
                    context,
                    3,
                    muteCallIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            builder.addAction(R.drawable.ic_volume_up, muteBtnTxt, muteCallPendingIntent);
        }

        // Yetki kontrolü
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "POST_NOTIFICATIONS permission not granted");
            return;
        }
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, builder.build());
    }

    /**
     * Android O ve üzeri için notification channel oluşturur.
     */
    private static void createNotificationChannelIfNeeded(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) return;

        NotificationChannel existing = manager.getNotificationChannel(CHANNEL_ID);
        if (existing != null) {
            // Zaten kanal varsa tekrar oluşturmaya gerek yok
            return;
        }

        // Kanal oluştur
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);

        // Bildirim kanalının sesini kapatıyoruz.
        channel.setSound(null, null);
        channel.enableVibration(true);

        manager.createNotificationChannel(channel);
    }

    /**
     * Zil sesini çalar (Activity yönetmiyorsa).
     */
    private static void playRingtone(Context context) {
        if (isRingtoneHandledByActivity) {
            return;
        }
        if (isRingtonePlaying && ringtone != null && ringtone.isPlaying()) {
            return;
        }
        try {
            Uri ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            if (ringtone == null) {
                ringtone = RingtoneManager.getRingtone(context, ringtoneUri);
            }

            // ÖNEMLİ: AudioAttributes veya setStreamType ile STREAM_RING'e geçmek
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && ringtone != null) {
                ringtone.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build());
            } else {
                // Daha eski sürümler
                if (ringtone != null) {
                    ringtone.setStreamType(android.media.AudioManager.STREAM_RING);
                }
            }

            if (ringtone != null && !ringtone.isPlaying()) {
                ringtone.play();
                isRingtonePlaying = true;
                Log.d(TAG, "Ringtone started playing by NotificationHelper");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error playing ringtone: " + e.getMessage(), e);
        }
    }

    /**
     * Zil sesini durdurur (Bildirimi silmez).
     */
    private static void stopRingtone() {
        if (isRingtoneHandledByActivity) {
            isRingtonePlaying = false;
            return;
        }
        try {
            if (ringtone != null && ringtone.isPlaying()) {
                ringtone.stop();
                Log.d(TAG, "Ringtone stopped by NotificationHelper");
            }
            ringtone = null;
            isRingtonePlaying = false;
        } catch (Exception e) {
            Log.e(TAG, "Error stopping ringtone: " + e.getMessage(), e);
        }
    }

    /**
     * Zil sesi + Bildirimi aynı anda durdurmak için çağrılır.
     */
    public static void stopRingtoneAndNotification(Context context) {
        stopRingtone();
        clearCallNotification(context);
    }

    /**
     * Çağrı durum değiştiğinde tetiklenir (ConnectionService veya InCallService üzerinden).
     */
    public static void handleCallStateChange(Context context, Call call) {
        if (call == null) {
            // Çağrı yok: tamamen sonlandır
            stopRingtoneAndNotification(context);
            isInCall = false;
            lastCallState = -1;
            return;
        }

        int callState = call.getState();
        Log.d(TAG, "Call state changed: " + getCallStateString(callState));

        // Aynı duruma tekrar girildiyse işlem yapma
        if (callState == lastCallState) {
            return;
        }
        lastCallState = callState;

        switch (callState) {
            case Call.STATE_ACTIVE:
                // Çağrı aktif: Zil sesini kapat, bildirim kalabilir (butonlarla)
                stopRingtone();
                isInCall = true;
                break;

            case Call.STATE_DISCONNECTED:
            case Call.STATE_DISCONNECTING:
                // Çağrı bitti: Her şey sonlansın
                stopRingtoneAndNotification(context);
                isInCall = false;
                break;

            case Call.STATE_RINGING:
                // Bu durum createIngoingCallNotification içerisinde yönetilir
                break;

            case Call.STATE_NEW:
            case Call.STATE_CONNECTING:
            case Call.STATE_DIALING:
            case Call.STATE_HOLDING:
            case Call.STATE_SELECT_PHONE_ACCOUNT:
            default:
                // Gerekirse ek mantık eklenebilir
                break;
        }
    }

    /**
     * Bildirimi panelden siler.
     */
    private static void clearCallNotification(Context context) {
        try {
            NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID);
            Log.d(TAG, "Call notification cleared");
        } catch (Exception e) {
            Log.e(TAG, "Error clearing notification: " + e.getMessage(), e);
        }
    }

    /**
     * Çağrı durumunu string olarak döndürme
     */
    private static String getCallStateString(int state) {
        switch (state) {
            case Call.STATE_NEW: return "STATE_NEW";
            case Call.STATE_RINGING: return "STATE_RINGING";
            case Call.STATE_DIALING: return "STATE_DIALING";
            case Call.STATE_ACTIVE: return "STATE_ACTIVE";
            case Call.STATE_HOLDING: return "STATE_HOLDING";
            case Call.STATE_DISCONNECTED: return "STATE_DISCONNECTED";
            case Call.STATE_CONNECTING: return "STATE_CONNECTING";
            case Call.STATE_DISCONNECTING: return "STATE_DISCONNECTING";
            case Call.STATE_SELECT_PHONE_ACCOUNT: return "STATE_SELECT_PHONE_ACCOUNT";
            default: return "UNKNOWN_STATE";
        }
    }
}
