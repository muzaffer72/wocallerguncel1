package com.whocaller.spamdetector.helpers;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Handler;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.InCallService;
import android.telecom.VideoProfile;
import android.widget.Toast;

import com.whocaller.spamdetector.R;


public class CallManager {
    public static final String ACTION_CALL = "action_call";
    public static final String ACTION_TIME = "action_time";
    private static Call call;
    public static Handler handler;

    public static String num;
    public static int status;
    public static int time;
    public AudioManager am;
    private final Context context;

    private boolean hold = false;
    public static int HP_CALL_STATE = 0;


    public static InCallService inCallService;
    private Object callback = new Call.Callback() {
        @Override
        public void onStateChanged(Call call2, int i) {
            super.onStateChanged(call2, i);

            HP_CALL_STATE = call.getState();

            if (i != 2) {
               // CallManager.this.stopSound();
            }
            Intent intent = new Intent(CallManager.ACTION_CALL);
            intent.putExtra("data", i);
            CallManager.this.context.sendBroadcast(intent);
            if (i != 4) {
                if (i == 10 && CallManager.handler != null) {
                    CallManager.handler.removeCallbacks(CallManager.this.runnable);
                }
            } else if (CallManager.handler != null) {
                CallManager.handler.removeCallbacks(CallManager.this.runnable);
                CallManager.handler.post(CallManager.this.runnable);
            }
        }
    };
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (CallManager.handler != null) {
                CallManager.handler.postDelayed(this, 1000);
                String time2 = getTime(CallManager.time);
                Intent intent = new Intent(CallManager.ACTION_TIME);
                intent.putExtra("time", time2);
                CallManager.this.context.sendBroadcast(intent);
                CallManager.time++;
            }
        }
    };

    public static String getTime(int i) {
        int i2 = i / 60;
        int i3 = i % 60;
        StringBuilder sb = new StringBuilder();
        if (i2 < 10) {
            sb.append("0");
        }
        sb.append(i2);
        sb.append(":");
        if (i3 < 10) {
            sb.append("0");
        }
        sb.append(i3);
        return sb.toString();
    }

    public CallManager(Context context) {
        this.context = context;
        this.am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
    }


    public final void setCall(Call call2) {
        Call call3 = call;
        if (call3 != null) {
            call3.unregisterCallback((Call.Callback) this.callback);
            this.hold = false;
            //stopRecorder();
            Handler handler2 = handler;
            if (handler2 != null) {
                handler2.removeCallbacks(this.runnable);
            }
        }
        if (call2 != null) {
            call2.registerCallback((Call.Callback) this.callback);
            status = call2.getState();
        }
        call = call2;
        if (call2 != null && call2.getState() == Call.STATE_RINGING) {
            //startSound();
        }
    }

    public Call getCall() {
        return call;
    }

    public void answer() {
        Call call2 = call;
        if (call2 != null) {
            call2.answer(0);
        }
    }
    public static void playDtmfTone(Call call, char c) {
        call.playDtmfTone(c);
        call.stopDtmfTone();
    }

    public void holdAndPlay() {
        if (call != null) {
            if (!this.hold) {
                Handler handler2 = handler;
                if (handler2 != null) {
                    handler2.removeCallbacks(this.runnable);
                }
                call.hold();
                this.hold = true;
                return;
            }
            Handler handler3 = handler;
            if (handler3 != null) {
                handler3.removeCallbacks(this.runnable);
                handler.postDelayed(this.runnable, 1000);
            }
            this.hold = false;
            call.unhold();
        }
    }

    public boolean isHold() {
        return this.hold;
    }

    public void hangup() {
        Call call2 = call;
        if (call2 != null) {
            call2.disconnect();
        }
    }



    public static void holdCall(Call mCall) {
        mCall.hold();
    }

    public static void unholdCall(Call mCall) {
        mCall.unhold();
    }

    public static void muteCall(boolean isMuted) {

        inCallService.setMuted(isMuted);

        if (isMuted) {
            Toast.makeText(inCallService, R.string.call_muted, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(inCallService, R.string.call_unmuted, Toast.LENGTH_SHORT).show();
        }
    }

    public static void speakerCall(boolean isSpeakerOn) {

        if (isSpeakerOn) {
            inCallService.setAudioRoute(CallAudioState.ROUTE_SPEAKER);
            Toast.makeText(inCallService, R.string.speaker_on, Toast.LENGTH_SHORT).show();
        } else {
            inCallService.setAudioRoute(CallAudioState.ROUTE_EARPIECE);
            Toast.makeText(inCallService, R.string.speaker_off, Toast.LENGTH_SHORT).show();
        }
    }

    public static void hangUpCall(Call mCall) {
        mCall.disconnect();
    }
    public static void answerCall(Call mCall) {
        mCall.answer(VideoProfile.STATE_AUDIO_ONLY);
    }
}
