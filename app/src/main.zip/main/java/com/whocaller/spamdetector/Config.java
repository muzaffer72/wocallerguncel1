/*
 * Company : AndroPlaza
 * Detailed : Software Development Company in Sri Lanka
 * Developer : Buddhika
 * Contact : support@androplaza.shop
 * Whatsapp : +94711920144
 */

package com.whocaller.spamdetector;

public class Config {
    public static final String BUSINESS = "1";
    public static final String PERSON = "0";

    public static final String UNKNOWN_CALLER_NAME = "Bilinmeyen";


    public static final Boolean CONTACTS_SYNC = true;

    //Replace your base url here..
    public static final String BASE_URL = "https://kisiler.onvao.net";

    //Replace your api key here..
    public static final String API_KEY = "a62647a12b7d35bd980bfdd95f2f90";
}